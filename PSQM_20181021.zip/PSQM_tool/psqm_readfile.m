% PSQM tool, T.Gafurov
% 2018-10-08

% The function to read the input text file   


function [Out_bus, Out_br_pline, Out_br_trans, Out_pldata, Out_error] = psqm_readfile(filename)


function [dumcell] = inner_func(ind_here)
    dumcell = {}; % Octave cell();
    n=0;
    for ii=ind_here
        rowdata = alltext{ii};    
        if ~isempty(rowdata)
            n=n+1;
            
            % remove delimiter in the end of line (if any)
            rowdata = strtrim(rowdata); % !first need to remove blank spaces
            if strcmp(rowdata(end), delimiter)                
                rowdata = rowdata(1:end-1);                          
            end
            
            % split, remove blank spaces at start and end
            final_res = strsplit(rowdata, delimiter, 'collapsedelimiters', false);
            final_res = strtrim(final_res);
            
            % convert to number if possible
            N_elem = max(size(final_res));
            for k=1:N_elem
                elem = final_res{k};
                [value, status] = str2num(elem);
                if status==1
                    final_res{k} = value; % overwrite 
                end
            end
            
            % save
            dumcell{n} = final_res;            
        end
    end
end % inner function


fid = fopen (filename, 'rt');

commment_symbol = '%';
delimiter = ',';

% extract data lines, find positions of the key data segments, remove comments  

dummy = -3;    
posbus_Exp_1 = dummy;
posbus_Exp_2 = dummy;
posbranch_1 = dummy;
posbranch_2 = dummy;
posPL_1 = dummy;
posPL_2 = dummy;
postrans_1 = dummy;
postrans_2 = dummy;


alltext = {}; % Octave: cell();
ncount=0;

while ~feof(fid)
    ncount=ncount+1;
    rowdata = fgetl (fid);
    
%%    if strfind(rowdata, 'Begin General data')
%%        posgen_1 = ncount + 1;
%%    
%%    elseif strfind(rowdata, 'End General data')
%%        posgen_2 = ncount-1;   


    if strfind(rowdata, 'Begin Bus data')    
        posbus_Exp_1 = ncount + 1;

    elseif strfind(rowdata, 'End Bus data') 
        posbus_Exp_2 = ncount-1;

    elseif strfind(rowdata, 'Begin Branch data: Power Line') 
        posbranch_1 = ncount + 1;

    elseif strfind(rowdata, 'End Branch data: Power Line') 
        posbranch_2 = ncount-1;
    
    elseif strfind(rowdata, 'Begin Power Line data') 
        posPL_1 = ncount + 1;

    elseif strfind(rowdata, 'End Power Line data') 
        posPL_2 = ncount-1;

    elseif strfind(rowdata, 'Begin Branch data: Transformer') 
        postrans_1 = ncount + 1;
        
    elseif strfind(rowdata, 'End Branch data: Transformer') 
        postrans_2 = ncount-1;
    
    else % remove comments (if any)
%          disp(rowdata)
        rowdata = strtrim(rowdata);
%         dumind = index(rowdata, commment_symbol); % first from left, Octave 
%         if dumind>0
%             rowdata = rowdata(1:dumind-1);
%         end    
        dumind = strfind(rowdata, commment_symbol);
        if ~isempty(dumind)
            dumind = dumind(1); % first index is used
            rowdata = rowdata(1:dumind-1);
        end 
    end   
    
    alltext{ncount}=rowdata;    
end % while


all_positions = [posbus_Exp_1, posbus_Exp_2, posbranch_1, posbranch_2, posPL_1, posPL_2, postrans_1, postrans_2];

if min(all_positions)==dummy % some of the data blocks not found

    fprintf('\nError: The input file seems to be corrupted. Check the data block limiters and file encoding. \n')
    Out_error = 1;
    
    Out_bus = [];
    Out_br_pline = [];
    Out_br_trans = [];
    Out_pldata = [];
    
else

    Out_error = 0;

    %%Out_general = inner_func(posgen_1:posgen_2);

    Out_bus = inner_func(posbus_Exp_1:posbus_Exp_2);

    Out_br_pline = inner_func(posbranch_1:posbranch_2);  

    Out_br_trans = inner_func(postrans_1:postrans_2);

    Out_pldata = inner_func(posPL_1:posPL_2);

end

fclose (fid); 


end % outer function