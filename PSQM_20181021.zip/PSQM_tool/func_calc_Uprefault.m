% Calculate prefault voltages in base units using Matpower
% T.Gafurov, 2017.09.28

function [U_pre] = func_calc_Uprefault(mpc, mpopt)

Nbus = size(mpc.bus,1);

% remove all constant power loads 
mpc.bus(:,3:4)=0;

PFres=runpf(mpc, mpopt); 

U_pre = ones(1,Nbus);

for n=1:Nbus;
    Umag=PFres.bus(n,8); phi=PFres.bus(n,9);
    U_pre(n) = Umag*(cosd(phi) + sind(phi)*1i);
end

end % function
