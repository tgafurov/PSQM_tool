% PSQM tool, T.Gafurov
% 2018-10-08

% The function performs LG, 2L, 2LG, 3L fault calculations and prints the results.
%
 

function [control_FaultC] = psqm_post_FaultC(mpc, mpopt, ...
          mpc_zero, mpc_neg, fb, fault_type, Zf, angle_code)

borderline_main = ' >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>';
borderline_sub  =' ------- ';

control_FaultC = zeros(1,6); % fault currents at fault bus (1-3) and from currents at first branch (4-6)
                 
%-------------------------------------------------------------------------------
% Constants
a=cosd(120)+sind(120)*i;
A=[1 1 1; 1 a^2 a; 1 a a^2];
%% [abc] = A*[012]


%-------------------------------------------------------------------------------
% Preparing inputs: General parameters
Nbus = size(mpc.bus,1);
Nbranch = size(mpc.branch,1);


% Base power
S_base = mpc.baseMVA; 

% bus Ubase, Ibase
Ubase_all = zeros(1, Nbus);

for bus = 1:Nbus
    Ubase_all(bus) = mpc.bus(bus,10); % kV, L-L
end

Ib_all = 1000*S_base/sqrt(3)./Ubase_all; % A

% Base UIZ for fault bus
Ib_fb = Ib_all(fb);  % A
Zb_fb = Ubase_all(fb)^2/S_base; % ohm



%% Define dummy bus names if missing
%if isfield(mpc, 'bus_name')==0
%    for ib = 1:Nbus
%        mpc.bus_name{ib} = '---'; 
%    end 
%end

fault_bus = mpc.bus_name{fb};

%-------------------------------------------------------------------------------
% Preparing inputs: Pre-fault voltages

mpopt_pre = mpopt;
mpopt_pre.verbose = 0;
mpopt_pre.out.all = 0;
    
U_pre = func_calc_Uprefault(mpc, mpopt_pre); % pu
% convergence is not controlled here as it follows power flow calculations


%-------------------------------------------------------------------------------
% Ybus matrix for Thevenin equivalents

[Y0_bus, ~, ~] = func_mpc2YbusThev(mpc_zero);
[Y1_bus, ~, ~] = func_mpc2YbusThev(mpc);
[Y2_bus, ~, ~] = func_mpc2YbusThev(mpc_neg);


% branch Ybr 
Ybr0_all = cell(1, Nbranch);   
Ybr1_all = cell(1, Nbranch);   
Ybr2_all = cell(1, Nbranch);  

for br = 1:Nbranch 
    Ybr0_all{br} = func_calc_Ybr(mpc_zero, br); % Octave, Ybr0_all(br)
    Ybr1_all{br} = func_calc_Ybr(mpc, br); 
    Ybr2_all{br} = func_calc_Ybr(mpc_neg, br); 
end


if strcmp(fault_type, 'LG')==1 || strcmp(fault_type, '2LG')==1
    ground_code = 1;
else
    ground_code = 0;
end


%-------------------------------------------------------------------------------
%-------------------------------------------------------------------------------     


fprintf('\n\n%s\n', borderline_main)
fprintf(' %s FAULT ANALYSIS: fault_bus = %s, Zf = %d + j%d ohm \n', fault_type, fault_bus, real(Zf), imag(Zf))  

[I012_fb, U0_fault, U1_fault, U2_fault] = ...
    func_calc_fault_LLLG(fault_type, fb, Zf/Zb_fb, U_pre, Y0_bus, Y1_bus, Y2_bus);    

%---------------------------------------------------------------------------
% print BUS voltages
fprintf('\n\n')
fprintf(' %s BUS voltages and earthing currents %s \n\n', borderline_sub, borderline_sub)

fprintf('  Bus name           U_A               U_B               U_C        Ie_R    Ie_X           U0                U1                U2       \n')
fprintf('                  kV     deg        kV     deg        kV     deg      A       A         kV     deg        kV     deg        kV     deg      \n')


for bus=1:Nbus

    Ub_here = Ubase_all(bus); % kV, L-L  
        
    dum_012 = [U0_fault(bus); U1_fault(bus); U2_fault(bus)]; % pu
    dum_abc = A*dum_012;
    
    UkV_012 = dum_012*Ub_here/sqrt(3); % kV
    UkV_abc = dum_abc*Ub_here/sqrt(3);
    
    phi_012 = angle(dum_012)*180/pi();
    phi_abc = angle(dum_abc)*180/pi();
    
    busname = mpc.bus_name{bus}; % bus name
    
    % Get earthing resistor/reactor currents
    % small current (negligible in relative terms) might appear at some buses 
    % due to usage of Rlarge instead of Inf in seq0 model
    if mpc.bus(bus,2)==1  % PQ bus         
        
        Ishpar_zero = func_calc_Ish4bus(mpc_zero, bus, U0_fault(bus));  %  1-magn   2-phi_actual   3-Ires_rel   4- Iind_rel   5-phi_rel
        
        In_res = 3*Ishpar_zero(3);
        In_ind = 3*Ishpar_zero(4);        
    else
        In_res = 0; In_ind =0;
    end
    
    fprintf('%10s   %7.3f  %6.1f   %7.3f  %6.1f   %7.3f  %6.1f  %6.1f  %6.1f   %7.3f  %6.1f   %7.3f  %6.1f   %7.3f  %6.1f \n', ...
    busname, abs(UkV_abc(1)), phi_abc(1), abs(UkV_abc(2)), phi_abc(2), abs(UkV_abc(3)), phi_abc(3), In_res, In_ind, ...
                 abs(UkV_012(1)), phi_012(1), abs(UkV_012(2)), phi_012(2), abs(UkV_012(3)), phi_012(3))
                    
end        

%---------------------------------------------------------------------------
% print BRANCH current
if angle_code==0
    extrastr = '(absolute angles)';
else
    extrastr = '(relative angles)';
end

for PP = 1:2  % 1 - Trans, 2 - PL
    fprintf('\n\n')
    
    if PP==1  % Transf       
        fprintf(' %s BRANCH - Transformer currents %s %s \n\n', borderline_sub, extrastr, borderline_sub)
    else
        fprintf(' %s BRANCH - Power Line currents  %s %s \n\n', borderline_sub, extrastr, borderline_sub)
    end
    
    fprintf('          Bus name              Ifr_A             Ifr_B             Ifr_C       Ie_cap       3xIfr_0            Ifr_1             Ifr_2 \n')
    fprintf('      FROM           TO       A      deg        A      deg        A      deg      A         A      deg        A      deg        A      deg \n')

    
    clear dum_abc dum_012 Ib_here Ub_here % just in case
    fromto_code = 0; % 0 - from, 1 - to (decided to use From values, the flag is kept for testing)

    for jj=1:Nbranch
        
        Frombus = mpc.branch(jj,1);
        Tobus   = mpc.branch(jj,2);
        
        tap_br  = mpc.branch(jj,9);    
        
        if fromto_code == 0
            refbus = Frombus;  % "From" values are presented
        else
            refbus = Tobus;
        end
        
        % bus names
        name_From = mpc.bus_name{Frombus}; 
        name_To = mpc.bus_name{Tobus}; 
        
        
        % injected currents after fault at from/to buses
        Ifromto_0 = Ybr0_all{jj}*[U0_fault(Frombus); U0_fault(Tobus)]; % pu
        Ifromto_1 = Ybr1_all{jj}*[U1_fault(Frombus); U1_fault(Tobus)];
        Ifromto_2 = Ybr2_all{jj}*[U2_fault(Frombus); U2_fault(Tobus)];
        
        
        % regrouping the branch currents and converting to A
        Ifrom_012 = [Ifromto_0(1); Ifromto_1(1); Ifromto_2(1)]*Ib_all(Frombus); % A

        Ito_012 = [Ifromto_0(2); Ifromto_1(2); Ifromto_2(2)]*Ib_all(Tobus);  % A

        % define which currents (From or To) are printed    
        if fromto_code == 0
            Ibr_012 = Ifrom_012;  
        else
            Ibr_012 = Ito_012;
        end
        
        Ibr_abc = A*Ibr_012; 
                
        phi_012 = angle(Ibr_012)*180/pi();
        phi_abc = angle(Ibr_abc)*180/pi();
        
        phi_rel012 = angle([U0_fault(refbus); U1_fault(refbus); U2_fault(refbus)])*180/pi() - phi_012;
        phi_rel_abc = angle(A*[U0_fault(refbus); U1_fault(refbus); U2_fault(refbus)])*180/pi() - phi_abc;
        
        % assign which angles to show for branch currents
        if angle_code==0 % absolute
            selang_012 = phi_012;
            selang_abc = phi_abc;
            
        else % relative 
            selang_012 = phi_rel012;
            selang_abc = phi_rel_abc;
        end
        
        selang_012 = func_angle_bound180(selang_012); % format angles to [-180,+180]
        selang_abc = func_angle_bound180(selang_abc);
            
        % PL capacitive current to earth
        Bc0 = mpc_zero.branch(jj,5);  % total line charging susceptance (p.u.)  
        
        if Bc0>0  
            % total 3xI0, A (Ibase is the same for PL endpoints)
            I_cap2earth = 3*0.5*(abs(U0_fault(Frombus)) + abs(U0_fault(Tobus)))*Bc0*Ib_all(Frombus); 
        else
            I_cap2earth = 0;    
        end   
         
        if (PP==1 && tap_br>0 && ground_code==0) || (PP==2 && tap_br==0)  % Transformer data are printed only for 3L, 2L           
           
            fprintf('%10s   %10s  %7.1f   %6.1f  %7.1f   %6.1f  %7.1f   %6.1f  %6.1f  %7.1f   %6.1f  %7.1f   %6.1f  %7.1f   %6.1f  \n', ... 
            name_From, name_To, ...
                    abs(Ibr_abc(1)), selang_abc(1), abs(Ibr_abc(2)), selang_abc(2), abs(Ibr_abc(3)), selang_abc(3), I_cap2earth, ...               % absolute phi
                        3*abs(Ibr_012(1)), selang_012(1), abs(Ibr_012(2)), selang_012(2), abs(Ibr_012(3)), selang_012(3))
                                        
        end
        
        % save control parameters
        if jj == 1
            control_FaultC(4:6) = Ibr_abc'; % last branch "from" currents for abc phases
        end
    end

end % PP


%---------------------------------------------------------------------------
% print FAULT current
dum_012 = I012_fb*Ib_fb;
dum_abc = A*dum_012;

fprintf('\n\n')
fprintf(' %s FAULT current at <%s> (%s fault, Zf = %d + j%d ohm) %s \n\n', ...
        borderline_sub, fault_bus, fault_type, real(Zf), imag(Zf), borderline_sub)

phi_012 = angle(dum_012)*180/pi();
phi_abc = angle(dum_abc)*180/pi();

fprintf('        I_A               I_B               I_C              3*I0               I1                I2 \n')
fprintf('     A      deg        A      deg        A      deg        A      deg        A      deg        A      deg \n')

fprintf('%7.1f   %6.1f  %7.1f   %6.1f  %7.1f   %6.1f  %7.1f   %6.1f  %7.1f   %6.1f  %7.1f   %6.1f \n', ... 
    abs(dum_abc(1)), phi_abc(1), abs(dum_abc(2)), phi_abc(2), abs(dum_abc(3)), phi_abc(3),... 
    3*abs(dum_012(1)), phi_012(1), abs(dum_012(2)), phi_012(2), abs(dum_012(3)), phi_012(3))  

% save control parameters
control_FaultC(1:3) = dum_abc'; % fault currents at abc phases     


end % function


