% PSQM tool, T.Gafurov
% The given script runs power flow and fault current calculations for pre-defined test cases
% using "psqm_main" function, and then compares the obtained results with the 
% expected/reference results. The test cases and the expected results are obtained 
% from textbooks by recognized experts. 
% 2018.10.01


clear all
close all


%-------------------------------------------------------------------------------
% Define test cases
power_unit = 1;
angle_code = 0;

tt=0;
testcase_data = {}; %cell(); % 1 - input_file, 2 - fault_bus, 3 - fault_type, 4 - Zf, 5 - control_PF, 6 - control_FaultC

tt = tt+1;
testcase_data{tt, 1} = 'test_KTH_ex_6_3.txt';
testcase_data{tt, 2} = 'Bus_4';
testcase_data{tt, 3} = '3L';
testcase_data{tt, 4} = 0;  % Zf
testcase_data{tt, 5} = [-0.63666 - 0.46821i,  0.37460 - 0.04169i,  11.45269]; % control_PF
testcase_data{tt, 6} = [11.42085 + 636.54067i,  -556.97082 - 308.37959i,   545.54997 - 328.16109i, ...
                        0.56786 +   1.24216i,   -1.35967 -   0.12930i,  0.79181 -   1.11286i]; % control_FaultC

 

tt = tt+1;
testcase_data{tt, 1} = 'test_KTH_ex_7_14.txt'; % fault test is added by me
testcase_data{tt, 2} = 'Bus_4'; 
testcase_data{tt, 3} = '2L';
testcase_data{tt, 4} = 70;  % Zf
testcase_data{tt, 5} = [-222.49 - 7.62i,  209.64 - 39.08i,  138.05]; % control_PF
testcase_data{tt, 6} = [0, -1.1823e+003 + 6.6843e+002i,  1.1823e+003 - 6.6843e+002i, ...
         -7.6590e-002 - 7.6156e+001i,  -3.1346e+002 + 2.5422e+002i, 3.1353e+002 - 1.7806e+002i]; % control_FaultC

                         

tt = tt+1;
testcase_data{tt, 1} = 'test_VAST_ex_1.txt'; % 
testcase_data{tt, 2} = 'B'; 
testcase_data{tt, 3} = '3L';
testcase_data{tt, 4} = 0;  % Zf
testcase_data{tt, 5} = []; % control_PF
testcase_data{tt, 6} = [100.87 + 624.94i,  -591.65 - 225.12i,   490.78 - 399.83i, ...
                        100.87 + 624.94i,  -591.65 - 225.12i,   490.78 - 399.83i]; % control_FaultC

 
                       
tt = tt+1;
testcase_data{tt, 1} = 'test_VAST_ex_2.txt'; % 
testcase_data{tt, 2} = 'A_70'; 
testcase_data{tt, 3} = '3L';
testcase_data{tt, 4} = 0;  % Zf
testcase_data{tt, 5} = []; % control_PF
testcase_data{tt, 6} = [0.03 + 2339.23i,  -2025.84 - 1169.59i,  2025.82 - 1169.64i,  ...
                                254.91i,  -220.76 - 127.45i,  220.75 -  127.46i]; % control_FaultC

      
tt = tt+1;
testcase_data{tt, 1} = 'test_VAST_ex_3_4.txt'; % ex.3
testcase_data{tt, 2} = 'B_130'; 
testcase_data{tt, 3} = '3L';
testcase_data{tt, 4} = 0;  % Zf
testcase_data{tt, 5} = []; % control_PF
testcase_data{tt, 6} = [0.20 + 3898.13i,  -3375.98 - 1948.89i,   3375.77 - 1949.24i, ...
                        0.13 + 1730.23i,  -1498.48 -  865.00i,   1498.36 -  865.22i]; % control_FaultC

                                                  

tt = tt+1;
testcase_data{tt, 1} = 'test_VAST_ex_3_4.txt'; % ex.4
testcase_data{tt, 2} = 'C_130'; 
testcase_data{tt, 3} = 'LG';
testcase_data{tt, 4} = 0;  % Zf
testcase_data{tt, 5} = []; % control_PF
testcase_data{tt, 6} = [1.0870e-001 + 3.2741e+003i,  0, 0, ...
           6.7466e-002 + 1.1916e+003i,  -7.6019e-003 - 3.0040e+002i,  -2.4240e-002 - 3.0040e+002i]; % control_FaultC

                         
                        
tt = tt+1;
testcase_data{tt, 1} = 'test_Graigner_ex_9_5.txt'; % 
testcase_data{tt, 2} = 'dummy'; 
testcase_data{tt, 3} = 'LG';
testcase_data{tt, 4} = 0;  % Zf
testcase_data{tt, 5} = [-136.81 -  83.52i,   234.52 +   6.23i,   309.11]; % control_PF
testcase_data{tt, 6} = []; % control_FaultC


tt = tt+1;
testcase_data{tt, 1} = 'test_Graigner_ex_9_5_regtr.txt'; % 
testcase_data{tt, 2} = 'dummy'; 
testcase_data{tt, 3} = 'LG';
testcase_data{tt, 4} = 0;  % Zf
testcase_data{tt, 5} = [-136.97 - 91.33i,  223.88 - 16.40i,  627.81]; % control_PF
testcase_data{tt, 6} = []; % control_FaultC
                        

tt = tt+1;
testcase_data{tt, 1} = 'test_Graigner_ex_9_7.txt'; % 
testcase_data{tt, 2} = 'dummy'; 
testcase_data{tt, 3} = 'LG';
testcase_data{tt, 4} = 0;  % Zf
testcase_data{tt, 5} = [-0.79881 - 0.66165i,  0.99850 - 0.03878i,  416.01132]; % control_PF
testcase_data{tt, 6} = []; % control_FaultC
                            

tt = tt+1;
testcase_data{tt, 1} = 'test_Graigner_ex_9_8.txt'; % 
testcase_data{tt, 2} = 'dummy'; 
testcase_data{tt, 3} = 'LG';
testcase_data{tt, 4} = 0;  % Zf
testcase_data{tt, 5} = [-0.79980 - 0.66440i,  0.99979 - 0.01263i,  421.18567]; % control_PF
testcase_data{tt, 6} = []; % control_FaultC
                                                        
                        
tt = tt+1;
testcase_data{tt, 1} = 'test_Graigner_ex_12_2.txt'; % 
testcase_data{tt, 2} = 'T2_345'; 
testcase_data{tt, 3} = 'LG';
testcase_data{tt, 4} = 0;  % Zf
testcase_data{tt, 5} = []; % control_PF
testcase_data{tt, 6} = [2.1848e-002 + 9.3138e+002i,  0, 0,  ...
     5.3987e-003 + 3.2548e+002i,  1.3505e-004 - 4.1842e+001i,  1.3497e-004 - 4.1842e+001i]; % control_FaultC
 
 
tt = tt+1;
testcase_data{tt, 1} = 'test_Graigner_ex_12_3.txt'; % 
testcase_data{tt, 2} = 'T2_345';  % ex. 12.3
testcase_data{tt, 3} = '2L';
testcase_data{tt, 4} = 0;  % Zf
testcase_data{tt, 5} = []; % control_PF
testcase_data{tt, 6} = [0,  -854.66316 + 0.03185i,  854.66316 - 0.03185i, ...
                        0,  -337.06528 + 0.00949i,  337.06528 - 0.00949i]; % control_FaultC
 
 
tt = tt+1;
testcase_data{tt, 1} = 'test_Graigner_ex_12_3.txt'; % 
testcase_data{tt, 2} = 'M2';  % ex. 12.4
testcase_data{tt, 3} = '2LG';
testcase_data{tt, 4} = 0;  % Zf
testcase_data{tt, 5} = []; % control_PF
testcase_data{tt, 6} = [0,  -1.74024e+004 - 8.2689e+003i,  1.74021e+004 - 8.2706e+003i, ...
       -1.1409e-003 + 9.0033e+001i,  -2.8419e+002 - 4.5010e+001i,  2.8419e+002 - 4.5023e+001i]; % control_FaultC
                         
                        

     
%-------------------------------------------------------------------------------
% Run test cases
N_tests = tt;

control_results = zeros(N_tests, 3); % 1 - Convergence, 2 - PF results,  3- FaultC results

code_ignored = 9;
code_success = 1;
code_deviation = 2; 

sum_errors = zeros(1,3);

tests2run = 1:N_tests;

for tt = tests2run
    
    input_file = testcase_data{tt, 1};
    fault_bus = testcase_data{tt, 2};
    fault_type = testcase_data{tt, 3};
    Zf = testcase_data{tt, 4};    
    ref_PF = testcase_data{tt, 5};
    ref_FaultC = testcase_data{tt, 6};
    
    [error_code, PFres, control_PF, control_FaultC] = psqm_main(input_file, power_unit, fault_bus, fault_type, Zf, angle_code); 
       
    if error_code > 0 % basic control
        sum_errors(1) = sum_errors(1) + 1; 
        
    else        
        control_results(tt, 1) = code_success; % mpc created and PF converged
        
        % PF control   
        if isempty(ref_PF) == 1
            code_sel = code_ignored; % not controlled
            
        else
            diff = abs(ref_PF - control_PF); % three values
            if max(diff)>0.01 % MVA, kV, A 
                code_sel = code_deviation; % deviation
                sum_errors(2) = sum_errors(2) + 1; 
            else
                code_sel = code_success;
            end            
        end       
        control_results(tt, 2) = code_sel;
        
        
        % FaultC control
        if isempty(ref_FaultC) == 1
            code_sel = code_ignored; % not controlled
            
        else
            diff = abs(ref_FaultC - control_FaultC); 
            if max(diff)>0.1 % A 
                disp(ref_FaultC)
                disp(control_FaultC)
                
                code_sel = code_deviation; % deviation
                sum_errors(3) = sum_errors(3) + 1; 
            else
                code_sel = code_success;
            end            
        end       
        control_results(tt, 3) = code_sel;
               
    end
end       


%-------------------------------------------------------------------------------
% Print results
clc
close all

fprintf('\nResults from PSQM tests: \n\n')
fprintf('  #     Initial     Power_flow     Fault_current     Fault_type     Input_file  \n')
 
for tt = tests2run
    input_file = testcase_data{tt, 1};
    fault_type = testcase_data{tt, 3};
    
    msgstr = {}; %cell();
    if control_results(tt, 1) == code_success
        msgstr{1} = 'OK';
        
        for col = 2:3
            code_here = control_results(tt, col);
            if code_here == code_success
                msgstr{col} = 'OK';
                
            elseif code_here == code_deviation
                msgstr{col} = 'Error';
            else
                msgstr{col} = '---';                
            end
        end 
        
        if control_results(tt, 3) == code_ignored 
            fault_type = '---';
        end
    
    else
        msgstr = {'Error', '---', '---'};
        fault_type = '---';
    end
    
    fprintf('%3d  %10s     %10s        %10s     %10s     %s \n', tt, msgstr{1}, msgstr{2}, msgstr{3}, fault_type, input_file)     
   
end

fprintf('\nN_errors:   %3d            %3d               %3d  \n\n', ...
            sum_errors(1), sum_errors(2), sum_errors(3))

if sum(sum_errors)==0
    fprintf('All tests have been successful. \n\n')
    
else
    fprintf('WARNING: Some errors have been detected during the tests. \n')
    fprintf('Check if you have the original example/script files. \n')
    fprintf('If the errors do not dissappear, report it at the GitHub repository webpage. \n\n')
end

