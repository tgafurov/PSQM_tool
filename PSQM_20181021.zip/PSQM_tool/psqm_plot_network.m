% PSQM tool, T.Gafurov
% 2018-10-08

% Data format
% bus_coord: H, V, U_angle
% branches: from, to, branch type (0-PL, 1-transf), transf. Rn1,Xn1,Rn2,Xn2



function psqm_plot_network(bus_names, bus_coord, branches, code_swingbus, code_PUbus, plot_param)

%%plot_param = [15, 10, 2];


font_sz = plot_param(1);
marker_cz = plot_param(2);
line_wd = plot_param(3);


line_def ='-b';
    

dX = 0.01*(max(bus_coord(:,1))-min(bus_coord(:,1))); % shift for text notes
dY = 0.02*(max(bus_coord(:,2))-min(bus_coord(:,2)));


N_bus=size(bus_coord,1);
N_branch=size(branches,1);


% count number of branches for each bus pair
closedbrnumb_4buspair = zeros(N_bus, N_bus);

for ii=1:N_branch
    ind1=branches(ii,1);
    ind2=branches(ii,2);
        
    a = min(ind1, ind2);
    b = max(ind1, ind2);
    
    closedbrnumb_4buspair(a,b)=closedbrnumb_4buspair(a,b) + 1;      
end     


figure('name','Network topology')
hold on
grid on


% Plot branches
buspairs_withparallbr = {}; %cell();
N_buspair_parbr = 0; 
for ii=1:N_branch
    ind1=branches(ii,1);
    ind2=branches(ii,2);
    
    branch_type=branches(ii,3);  % 0-PL, otherwise-transf.
    
    Zn_trans = branches(ii,4:7); % Rn1, Xn1, Rn2, Xn2

    X1=bus_coord(ind1,1);
    Y1=bus_coord(ind1,2);
    
    X2=bus_coord(ind2,1);
    Y2=bus_coord(ind2,2);
    
    % center of the branch (used for transformer symbol, parall branches)        
    X_center = X1 + 0.5*(X2-X1); 
    Y_center = Y1 + 0.5*(Y2-Y1); 
    
    % plot straight line    
    plot([X1,X2], [Y1,Y2], line_def, 'linewidth', line_wd) 
    
    % add symbol for transformers
    if branch_type~=0 %       
         
        if (Zn_trans(1)==0 || Zn_trans(2)==0) && (Zn_trans(3)==0 || Zn_trans(4)==0)
            
            % link in zero sequence, no shunts
            trface_color = 'r';
        else
            trface_color = 'w';
            
            if Zn_trans(1)~=Inf || Zn_trans(2)~=Inf % shunt at Frombus
                X_neutral = X1 + 0.6*(X_center-X1); 
                Y_neutral = Y1 + 0.6*(Y_center-Y1);                

                plot(X_neutral, Y_neutral,'rv', 'markersize', marker_cz, 'MarkerFaceColor', 'r', 'linewidth', line_wd)
            end  
            
            if Zn_trans(3)~=Inf || Zn_trans(4)~=Inf % shunt at Tobus
                X_neutral = X2 + 0.6*(X_center-X2);
                Y_neutral = Y2 + 0.6*(Y_center-Y2); 
                
                plot(X_neutral, Y_neutral,'rv', 'markersize', marker_cz, 'MarkerFaceColor', 'r', 'linewidth', line_wd) 
            end 
            
        end    
        plot(X_center,Y_center,'bh', 'markersize', 2.5*marker_cz, 'MarkerFaceColor', trface_color, 'linewidth', line_wd)  %  
%        text(X_trafo,Y_trafo,'Transf', 'fontsize', font_sz, 'fontweight', 'bold')     
    end
     
    
    % annotation for parallel branches
    a = min(ind1, ind2);
    b = max(ind1, ind2);
    N_closed = closedbrnumb_4buspair(a,b);
   
    buspair = strcat(num2str(a),'--',num2str(b));
    if func_ifstr_incell(buspairs_withparallbr, buspair)==0 && N_closed >1
    % more than one branch between given two buses
        str = strcat('n=', num2str(N_closed));
        text(X_center+dX, Y_center-dY, str, 'fontsize', font_sz, 'fontweight', 'bold')    
        
        N_buspair_parbr = N_buspair_parbr + 1; 
        buspairs_withparallbr{N_buspair_parbr} = buspair;          
    end  
end

if N_buspair_parbr>0
    fprintf('Note: %d bus pair(s) with parallel branches:', N_buspair_parbr)
    for j=1:N_buspair_parbr
        fprintf(' %s  /', buspairs_withparallbr{j})
    end
    fprintf('\n')        
end



% Plot buses (only the ones used in branches)
dum = branches(:,1:2);
buses_inbr = unique(dum(:))';

for ii = buses_inbr % 1:N_bus

%    name = strcat(num2str(ii), '-', bus_names{ii}); % numb+name
    name = bus_names{ii}; % only name

    X = bus_coord(ii,1);
    Y = bus_coord(ii,2);
    
    if bus_coord(ii,3) == code_swingbus
        plot(X, Y,'rs', 'markersize', 1.5*marker_cz, 'MarkerFaceColor', 'r')
    
    elseif bus_coord(ii,3) == code_PUbus
        plot(X, Y,'gs', 'markersize', 1.5*marker_cz, 'MarkerFaceColor', 'g')    
    
    else  % PQ bus
        plot(X, Y,'bs', 'markersize', marker_cz, 'MarkerFaceColor', 'b')    
    end
    
    text(X+dX, Y+dY, name, 'Interpreter', 'none', 'fontsize', font_sz, 'fontweight', 'bold') 
end

end % function
