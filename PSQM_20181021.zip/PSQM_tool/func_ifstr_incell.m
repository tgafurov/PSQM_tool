% Function to check if cell elements contains given string  

function [out] = func_ifstr_incell(targetcell, str_in)

if isempty(targetcell)
    out = 0;    
else 
    out = max(strcmp(targetcell, str_in)); 
end

end % function