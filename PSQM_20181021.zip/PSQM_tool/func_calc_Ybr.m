% PSQM tool, T.Gafurov 
% Calculates Ybr matrix given branch according to equation (3.2) in Matpower Manual (version 6)
% 2018-10-01

function [Ybr] = func_calc_Ybr(mpc, jj)
    
Rs = mpc.branch(jj,3);
Xs = mpc.branch(jj,4); 
Bc = mpc.branch(jj,5);
tau = mpc.branch(jj,9); % tap
shift = mpc.branch(jj,10)*pi()/180; % phase shift in radians

if tau==0
    tau = 1;
end

ys = 1/(Rs+1i*Xs);
Ybr = [(ys+1i*Bc/2)/tau^2,  -ys/(tau*exp(-1i*shift));  -ys/(tau*exp(1i*shift)), ys+1i*Bc/2];
 
end % function
    