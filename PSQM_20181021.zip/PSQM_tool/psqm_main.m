% PSQM tool, T.Gafurov
% Main function to run the simulation



function [error_code, PFres, control_PF, control_FaultC] = psqm_main(input_file, power_unit, fault_bus, fault_type, Zf, angle_code) 


clc
% ------------------------------------------------------------------------------
% Simple check of the function inputs

error_code = 0;
PFres = []; control_PF = zeros(1,3); control_FaultC = zeros(1,6); % dummy output values 

if ischar(input_file)==0  ||  ischar(fault_bus)==0  ||  ischar(fault_type)==0 % not string
    error_code = 1;
end


if isnumeric(Zf)==0 || isnumeric(power_unit)==0 || isnumeric(angle_code)==0  % not numeric
    error_code = 1;

elseif real(Zf)<0 % negative resistance
    error_code = 1;
end

if error_code>0
    disp('Error in function inputs')
    return
end

if exist(input_file, 'file')==0
    error_code=1;
    fprintf('\n The input file <%s> is not found. \n Check if the file name is correct and the location path is added.\n', input_file)
    return
end
    
% ------------------------------------------------------------------------------
% Load the general inputs/constants (S_base, MP parameters, etc)
PSQM_settings  

plot_param = [plot_fontsize, plot_markersize, plot_linewidth];

% ------------------------------------------------------------------------------
% Convert input file to mpc struct (Matpower format)
[mpc, mpc_zero, mpc_neg, ~, error_code] = psqm_inputfile2mpc(input_file, MP_version, S_base, standard_Ubase, plot_param);
 
if error_code>0
    return
end


% ------------------------------------------------------------------------------
% Define Matpower options 

if mult_max_iter<1 
    mult_iter = 1;
    
elseif mult_max_iter>10
    mult_iter = 10;    
else
    mult_iter = mult_max_iter;
end


mpopt = mpoption(); % initialise

mpopt.pf.nr.max_it = floor(mult_iter*mpopt.pf.nr.max_it); 
mpopt.pf.gs.max_it = floor(mult_iter*mpopt.pf.gs.max_it);

%mpopt.verbose = 0; 
%mpopt.out.sys_sum = 0;
%mpopt.out.bus = 0;
%mpopt.out.branch = 0;
mpopt.out.all = 0;

if PF_method == 0     
    mpopt.pf.alg = 'NR';  % Newton-Raphson (default in Matpower)   
else  
    mpopt.pf.alg = 'GS'; % Gauss-Seidel
end    


% ------------------------------------------------------------------------------
% Power flow calculations

[PFres, error_code, control_PF] = psqm_post_PowerF(mpc, mpopt, power_unit);

if error_code>0
    return
end


% ------------------------------------------------------------------------------
% Fault current calculations

% check if fault type/bus is valid
faultinput_invalid = 0;

err_msg = ' Fault analysis is not performed.';

if any(strcmp({'LG', '2LG', '2L', '3L'}, fault_type))==0  % unknown fault type

    faultinput_invalid = 1;    
    fprintf('\n%s Invalid fault type. \n', err_msg)

elseif  func_ifstr_incell(mpc.bus_name, fault_bus)==1
    fb = find(strcmp(mpc.bus_name, fault_bus)==1);
    
    if mpc.bus(fb,2)~=1 % not  PQ bus
        faultinput_invalid = 1;
        fprintf('\n%s Fault bus is not PQ bus. \n', err_msg)
    end
    
else % unknown fault bus        
    faultinput_invalid = 1;
    fprintf('\n%s Unknown fault bus. \n', err_msg)
end

if faultinput_invalid ==0
            
    control_FaultC = psqm_post_FaultC(mpc, mpopt, mpc_zero, mpc_neg, fb, fault_type, Zf, angle_code);
    
end

fprintf('\n The results above correspond to <%s>. \n', input_file) 

end % function
    
 
        
        
