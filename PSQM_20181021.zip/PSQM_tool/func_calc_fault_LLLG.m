% PSQM tool, T.Gafurov 
% Calculates the fault current and voltages after fault for 012 sequences using Zbus method.
% 2018-10-01

% The formulas are based on:
% - NPTEL lecture notes
% - (Das, 2017) Understanding Symmetrical Components

function  [I012_fb, U0_fault, U1_fault, U2_fault] = ...
            func_calc_fault_LLLG(fault_type, fb, Zf, U_pre, Y0, Y1, Y2)


Z0=inv(Y0);
Z1=inv(Y1);
Z2=inv(Y2);

Nbus = size(Y1,1); % total number of buses

U0_fault = zeros(1,Nbus); % initialized for all though calculated for selected buses
U1_fault = zeros(1,Nbus);
U2_fault = zeros(1,Nbus);


if isempty(U_pre)    
    U_pre = ones(1,Nbus);
end


switch fault_type

    case '3L' 

        Ia1=U_pre(fb)/(Z1(fb,fb)+Zf);  % eq.4.74 
        Ia2=0; Ia0=0;

    %-------------------------------------------------------------------------------
    case 'LG' % Ground fault (a)

        Ia0=U_pre(fb)/(Z1(fb,fb) + Z2(fb,fb) + Z0(fb,fb) + 3*Zf); %eq.4.101  
        Ia1=Ia0; Ia2=Ia0;

    %-------------------------------------------------------------------------------
    case '2L' % Phase-to-phase fault (b,c)

        Ia1=U_pre(fb)/(Z1(fb,fb) + Z2(fb,fb) + Zf);  % eq. 4.109  

        Ia0=0; Ia2=-Ia1;

    %-------------------------------------------------------------------------------
    case '2LG' % Double ground fault (b,c)

        dum = Z1(fb,fb) + Z2(fb,fb)*(Z0(fb,fb)+3*Zf)/(Z0(fb,fb)+Z2(fb,fb)+3*Zf);
        Ia1=U_pre(fb)/dum; % eq. 4.119 

        Ia0=-(U_pre(fb)-Ia1*Z1(fb,fb))/(Z0(fb,fb)+3*Zf);  % eq. 4.117 

        Ia2=-(U_pre(fb)-Ia1*Z1(fb,fb))/Z2(fb,fb);  % eq. 4.118 
end % switch

I012_fb = [Ia0; Ia1; Ia2];  % fault current

% Bus voltages after fault
for ii=1:Nbus            

    U0_fault(ii)=-Z0(ii,fb)*Ia0;   % eq. 4.75, 4.127
    U1_fault(ii)=U_pre(ii)-Z1(ii,fb)*Ia1; 
    U2_fault(ii)=-Z2(ii,fb)*Ia2;       
end 

end % function

