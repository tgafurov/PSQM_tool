% PSQM tool, T.Gafurov 
% The given function calculates:
% - R, X, off-nominal tap ratio for the transformer branch in positive sequence 
% according to Matpowers modelling approach
% - the equivalent zero sequence parameters according to own approach 

% 2018-10-01

function  [Rtrans, Xtrans, tapratio_MP_nom, tapratio_MP_OFFnom, Z0_sh1, Z0_sh2, Z0_12]=func_calc_transfparam(...
  Snom, U1_nom, U2_nom, uk, X2R, tap_relpos, tap_step, Sbase, U1_base, U2_base, input4zeroseq)

function XR = calc_XRtransformer(S)
% Approximate XR for self-cooled transformer according to Fig. 4A-1 in IEEE-141-1993
% Snom - nominal power in MVA

    % Based on approximation from 20170511
    if S<=2
        XR = 2.33*S+2.83;

    elseif S>2 && S<5
        XR = 10;

    elseif S>5 && S<200
        XR = 7.28*(S^0.355);

    else
        XR = 50;
    end
end    

if X2R ==0 
    X2R = calc_XRtransformer(Snom);
end

    

% "From" --- tapratio_offnom --- (R, X) --- "To"
% R, X are calculated for nominal tap ratio and "To" side
% tapratio = From_pu/To_pu

%---------------------------------------------------------------------------
% tap ratio
tap_multiplier = 1 + tap_relpos*tap_step/100;
tapratio_MP_nom = (U1_nom/U1_base)/(U2_nom/U2_base); % U1_nom(pu)/U2_nom(pu)
tapratio_MP_OFFnom = tapratio_MP_nom*tap_multiplier;  % as above, but with Uf_offnom


%---------------------------------------------------------------------------
% R, X for positive sequence    
%    Z2_base = U2_nom^2/Sbase  # base impedance for "To" bus
Z2_base = U2_base^2/Sbase;  % base impedance for "To" bus, corrected 

Ztrans = uk*(U2_nom^2/Snom)/Z2_base; % corrected from Xtrans to Ztrans    

Rtrans = Ztrans/(X2R^2 + 1)^0.5;   

Xtrans = (Ztrans^2 - Rtrans^2)^0.5;


%---------------------------------------------------------------------------
% equivalent Pi-model impedances for zero sequence  

% max resistance (pu) to model open branch (to replace R=Inf)
% Rlarge (pu) = Sbase/S_sc, where S_sc - the short-circuit power of given branch
% Too high Rlarge may lead to warning "matrix singular to machine precision" at Sbase=100 MVA  
  
Rlarge = Sbase*10^5; % S_sc = 10 VA, 

Z0_sh1 = Inf;   Z0_sh2 = Inf;  Z0_12 = Rlarge;  % default values
    
if iscell(input4zeroseq)==0

    if input4zeroseq==0
        dummy = 0; % pass

    else
        fprintf('\nError: uknown "input4zeroseq" format/value in "func_MP_transfparam" \n\n')
        return
    end
else
       

    % inputs:     
    Rn1_ini = input4zeroseq{1}; % ohm, resistance/reactance at neutral point 
    Xn1_ini = input4zeroseq{2}; 
    Rn2_ini = input4zeroseq{3}; 
    Xn2_ini = input4zeroseq{4};

    if min(Rn1_ini, Xn1_ini)==0 && min(Rn2_ini, Xn2_ini)==0 % No break and No shunts in zero sequence 
        
        Z0_12 = complex(Rtrans, Xtrans); % Z0_12=Z_trans, Z0_sh1=Z0_sh2=Inf
    
    else  
        % With break and with optional shunts in zero sequence   
        % transformer zero seq. impedance ignored     
    
       
        % limit Rn, Xn to void error "division by zero" (required for parallel connection) 170824
        Rn1 = Rn1_ini + 1/Rlarge;  Rn1 = min(Rlarge, Rn1);
        Rn2 = Rn2_ini + 1/Rlarge;  Rn2 = min(Rlarge, Rn2);
        Xn1 = Xn1_ini + 1/Rlarge;
        Xn2 = Xn2_ini + 1/Rlarge;

     
        % Rn, Xn are parallel, convert to pu
        % note the pu-value depends only on U_base (not affected by transf. tap)
        Z1_base = U1_base^2/Sbase;
        Zn_1 = 1/complex(1/Rn1, -1/Xn1)/Z1_base;   
        
        Zn_2 = 1/complex(1/Rn2, -1/Xn2)/Z2_base; 
        
        
        % Define the "From" shunt Z0_sh1         
        if Rn1_ini~=Inf || Xn1_ini~=Inf    
            
            Z0_sh1 = 3*Zn_1; 
        end
        
        % Define the "To" shunt Z0_sh1         
        if Rn2_ini~=Inf || Xn2_ini~=Inf    
            
            Z0_sh2 = 3*Zn_2; 
        end       

    end     

    % Equivalent shunt power = S_base/Zsh_pu
    if min([real(Z0_sh1), real(Z0_sh2), real(Z0_12)])<0  
        fprintf('Error: Transf. with R0<0: Snom =%d, uk=%d,  R0(Pi-model)=%d/%d/%d  \n', ...
        Snom, uk, real(Z0_sh1), real(Z0_sh2), real(Z0_12))
    end 
end 

end % function