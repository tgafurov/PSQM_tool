% Main parameters for PSQM tool

S_base = 100; % Base power, MVA

% Base line voltages, kV, mainly based on old/new nominal values from standards
standard_Ubase = [0.4, 0.69, 1, 3.3, 6.6, 11, 22, 33, 45, 66, 110, 138, 150, 220, 345, 400, 500, 765, 1100]; 


MP_version = '2';  % Matpower version


PF_method = 0; % 0 - Newton-Raphson (default), 1 - Gauss-Seidel


mult_max_iter = 1; % multiplier for default max number of iterations [1-10]


% plot settings 
plot_fontsize = 15;
plot_markersize = 10;
plot_linewidth = 2;

