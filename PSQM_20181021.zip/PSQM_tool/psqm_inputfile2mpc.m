% PSQM tool, T.Gafurov 

% The given function performs the following:
% - reads input file and checks for some possible errors (eg. missing slack bus, duplicate
% buses, same from/to buses, etc)
% - calculates impedances for transformer and power line branches 
% - converts the calculated grid parameters into Matpower format ("mpc" struct).
% - creates the corresponding data structures for negative and sero sequences required 
% for fault current calculations

% The code is somewhat messy as it is adapted from various previous projects. 

% 2018-10-01




function [mpc, mpc_zero, mpc_neg, transfdata_out, error_code] = ...
    psqm_inputfile2mpc(input_file, MP_version, S_base, standard_Ubase, plot_param)

%-------------------------------------------------------------------------------
% 
% Constants

borderline_main = ' >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>';
message4return ='\nWARNING: Code execution is interrupted due to input errors \n\n';

Udev_limit = 0.2; % max deviation when choosing closest base voltage

code_slackbus = 333;

code_PUbus = 222;


fprintf('\n\n%s\n', borderline_main)
fprintf(' DATA PREPARATION \n') 

%-------------------------------------------------------------------------------
%-------------------------------------------------------------------------------
% PART I - Data check and plot

mpc=[]; mpc_zero=[]; mpc_neg=[]; transfdata_out=[]; % dummy values in case of code interupption
error_code = 0;

%-------------------------------------------------------------------------------
% Reading MGD file and defining general parameteres
[IN_bus, IN_pline, IN_trans, IN_pldata, input_error] = psqm_readfile(input_file);

if input_error>0
    error_code = 1;
    fprintf(message4return)
    return
end


N_inpline = size(IN_pline, 2); 
N_intrans = size(IN_trans, 2); 
N_inbus = size(IN_bus, 2); 
N_inpldata = size(IN_pldata, 2); 


%-------------------------------------------------------------------------------
fprintf('\nChecking power line data ... \n') 

% Reading power line data from input file            

if N_inpldata>0
    
    PLdata.name = cell(1, N_inpldata);
    PLdata.R = zeros(1, N_inpldata);
    PLdata.X = zeros(1, N_inpldata);
    PLdata.Bd = zeros(1, N_inpldata);
    PLdata.R0 = zeros(1, N_inpldata);
    PLdata.X0 = zeros(1, N_inpldata);
    PLdata.Bd0 = zeros(1, N_inpldata);
    
    plnames_iniset = {}; % Octave cell();
    n_pl = 0;
    
    for ii=1:N_inpldata
        onerow_data = IN_pldata{ii};
        N_elem = max(size(onerow_data));
        plname = onerow_data{1};
        
        % check number of parameters  
        if N_elem~=4 && N_elem~=7
            fprintf('Error: Wrong number of inputs for PL type <%s> (data row %d) \n', plname, ii)  
            error_code = 1;      
        end  
        
        % save PL name, check for duplicates    
        if func_ifstr_incell(plnames_iniset, plname)==1
            fprintf('Error: Duplicates for PL type <%s> (data row %d) \n', plname, ii)
            error_code = 1;    
        else        
            n_pl = n_pl + 1;
            plnames_iniset{n_pl} = plname;        
        end  
        
        % check number of parameters of float type
        N_floats = 0;  
        for k=1:N_elem    
            if isfloat(onerow_data{k})
                N_floats = N_floats + 1;
            end    
        end
        
        if N_floats~=N_elem-1  % Excl. PL name
            fprintf('Error: Wrong number of numeric inputs for PL type <%s> (data row %d) \n', plname, ii)   
            error_code = 1;    
            
        else
            % save data to "PLdata"
            PLdata.name{ii} = plname;
            PLdata.R(ii) = onerow_data{2}; 
            PLdata.X(ii) = onerow_data{3};
            PLdata.Bd(ii) = onerow_data{4};
            
            if N_elem == 7    
                PLdata.R0(ii) = onerow_data{5};
                PLdata.X0(ii) = onerow_data{6};
                PLdata.Bd0(ii) = onerow_data{7};
            else
                PLdata.R0(ii) = PLdata.R(ii);
                PLdata.X0(ii) = PLdata.X(ii);
                PLdata.Bd0(ii) = PLdata.Bd(ii);
            end
        end
                
    end %% for ii 

else  %% N_inpldata==0

    fprintf('Error: Power Line data are not defined. \n')  
    error_code = 1;   
end


if error_code>0
    fprintf(message4return)
    return
end


%-------------------------------------------------------------------------------
fprintf('\nChecking bus definitions ... \n') 
% Get bus names, add zero shunts 
% "IN_bus" elements: Name(1),  H(2),  V(3),  Ubase(4),   Pd(5),    Qd(6),   Psh(7),   Qsh(8), U(9), phi(10)   
busset_inbus = {}; % cell();

N_slack = 0; 
ind_PUbus = []; N_PUbus = 0; 

VmVa_fromuser = zeros(N_inbus,2);

for ii=1:N_inbus
    
    onerow_data = IN_bus{ii};
    N_elem = max(size(onerow_data));
    busname = onerow_data{1};
    
    % check number of parameters  
    if N_elem~=6 && N_elem~=8 && N_elem~=10  % neither of (6, 8, 10)
        fprintf('Error: Wrong number of inputs for bus <%s> (data row %d) \n', busname, ii)  
        error_code = 1;      
    end  
    
    % check number of parameters of float type
    N_floats = 0;  
    for k=1:N_elem    
        if isfloat(onerow_data{k})
            N_floats = N_floats + 1;
        end    
    end
    
    if N_floats~=N_elem-1  % Excl. bus name
        fprintf('Error: Wrong number of numeric inputs for bus <%s> (data row %d) \n', busname, ii)   
        error_code = 1;  
    else
        % check if base voltage is close enough to "standard" value
        Ubase_ini = onerow_data{4};    
    
        if func_closestvalue(standard_Ubase, Ubase_ini, Udev_limit)==0
            fprintf('Error: High difference between the given and standard Ubase values for bus <%s> (data row %d) \n', busname, ii)  
            error_code = 1;   
        end
     
    end
    
    % add zero shunts if needed
    if N_elem==6 
%         onerow_data(7:8) = 0; % add zero shunts, Octave
        onerow_data{7}=0;
        onerow_data{8}=0;
        IN_bus{ii}=onerow_data; % update        
    end
    
    % save bus name, check for duplicates    
    if func_ifstr_incell(busset_inbus, busname)==1
        fprintf('Error: Duplicates for bus <%s> (data row %d) \n', busname, ii)
        error_code = 1;    
    else      
        busset_inbus{end+1} = busname;        
    end        
    
    % save index of slack, PU buses and "VmVa_fromuser" (used later)     
    if N_elem==10    
        V_magn = onerow_data{9};
        V_angle = onerow_data{10};
        VmVa_fromuser(ii,:) = [V_magn, V_angle];
        
        if V_angle == code_slackbus % slack bus
            N_slack = N_slack + 1;
            ind_slack = ii; % single slack bus
            
        elseif V_angle == code_PUbus   % PU bus
            N_PUbus = N_PUbus + 1;
            ind_PUbus = [ind_PUbus, ii];   
        end 
    
    end
    
end

% additional check for slack bus
if N_slack == 0
    fprintf('Error: Slack bus is missing \n')
    error_code = 1;    
    
elseif N_slack > 1
    fprintf('Error: Multiple slack buses \n')
    error_code = 1;
end

if error_code>0
    fprintf(message4return)
    return
end


%-------------------------------------------------------------------------------
fprintf('\nChecking power line definitions ... \n')  
% Get bus names, prepare PL parameters
% "N_inpline" elements: % frombus(1),   tobus(2),  Segm_1 type(3), Segm_1 length(4), ... Segm_N type, Segm_N length   
busset_4branches = {}; %cell(); % busnames from IN_pline and later from IN_trans

segmnumb_inpline = zeros(1, N_inpline);

ncount_pltypes = 0;

PL_nameextra = {}; %cell(); % used to check pl names

for ii=1:N_inpline
    
    onerow_data = IN_pline{ii};
    N_elem = max(size(onerow_data));
    name_from = onerow_data{1};
    name_to = onerow_data{2};
    
    % check number of parameters (must be even)  
    if rem(N_elem,2)==1 % odd
        fprintf('Error: Odd number of inputs for line <%s - %s> (data row %d) \n', name_from, name_to, ii) 
        error_code = 1;           
    end       
    
    % check number of parameters of float type
    N_floats = 0;  
    for k=1:N_elem    
        if isfloat(onerow_data{k})
            N_floats = N_floats + 1;
        end    
    end
    
    N_segm = (N_elem-2)/2;  % minus busfrom and busto
    if N_floats~=N_segm  % segm lengths 
        fprintf('Error: Wrong number of numeric inputs for line <%s - %s> (data row %d) \n', name_from, name_to, ii)  
        error_code = 1;           
    end   
    segmnumb_inpline(ii) = N_segm;
    
    
    % check if to/from buses same    
    if strcmp(name_from, name_to)
        fprintf('Error: Same from/to buses for line: <%s - %s> (data row %d) \n', name_from, name_to, ii) 
        error_code = 1;    
    end
    
    % check if buses are defined
    if func_ifstr_incell(busset_inbus, name_from)==0 || func_ifstr_incell(busset_inbus, name_to)==0
        fprintf('Error: Undefined bus(es) for line <%s - %s> (data row %d) \n', name_from, name_to, ii) 
        error_code = 1;    
    end
    
    % save From bus  
    if func_ifstr_incell(busset_4branches, name_from)==0 
        busset_4branches{end+1} = name_from;
    end 

    % save To bus  
    if func_ifstr_incell(busset_4branches, name_to)==0
        busset_4branches{end+1} = name_to;
    end   

    %-------------------------------
    % Get PL types and assign parameters        
    for vv=3:2:N_elem % according to IN_pline format
        plstr = onerow_data{vv};
        
        if func_ifstr_incell(PL_nameextra, plstr)==0                        
            
            ncount_pltypes = ncount_pltypes + 1;           
            
            % check if its available in PL data
            ipl = find(strcmp(PLdata.name, plstr)==1); 
            if isempty(ipl)
                fprintf('Error: Undefined power line type <%s> (data row %d) \n', plstr, ii)    
                error_code = 1;    
            else      
                                 
                PL_nameextra{ipl} = plstr; % used later to get PL index  
        
            end
        end
    end  % vv    
  
end



%-------------------------------------------------------------------------------
fprintf('\nChecking transformer definitions ... \n')  % get bus names
% "IN_trans" elements: frombus(1), tobus(2), Snom(3), U1(4), U2(5), Zk(5), X/R(7), tap_relpos(8), tap_step(9), phi(10), Rn1,Xn1,Rn2,Xn2 (11-14)  


for ii=1:N_intrans
    
    onerow_data = IN_trans{ii};
    N_elem = max(size(onerow_data));
    name_from = onerow_data{1};
    name_to = onerow_data{2};
    phase_shift = onerow_data{10};
    
    % check number of parameters  
    if N_elem~=10 && N_elem~=14 % seq0 data are optional
        fprintf('Error: Wrong number of inputs for transformer <%s - %s> (data row %d) \n', name_from, name_to, ii) 
        error_code = 1;           
    end       
    
    % check number of parameters of float type
    N_floats = 0;  
    for k=1:N_elem    
        if isfloat(onerow_data{k})
            N_floats = N_floats + 1;
        end    
    end
    
    if N_floats~=N_elem-2  % excl. bus names 
        fprintf('Error: Wrong number of numeric inputs for transformer <%s - %s> (data row %d) \n', name_from, name_to, ii)
        error_code = 1;            
    
    elseif rem(phase_shift,30)~=0  
        fprintf('Note: Irregular phase shift for transformer <%s - %s> (data row %d), phi=%d deg \n', name_from, name_to, ii, phase_shift)                    
    end 
    
    % add default seq0 data if needed 
    if N_elem==10 
        % 11-14: default: Zn1=Zn2=inf, Z0=Inf
        onerow_data(11:14) = {Inf, Inf, Inf, Inf};  
        IN_trans{ii}=onerow_data; % update        
    end
        
    % check if to/from buses same    
    if strcmp(name_from, name_to)
        fprintf('Error: Same from/to buses for transformer <%s - %s> (data row %d) \n', name_from, name_to, ii) 
        error_code = 1;    
    end
    
    % check if buses are defined
    if func_ifstr_incell(busset_inbus, name_from)==0 || func_ifstr_incell(busset_inbus, name_to)==0
        fprintf('Error: Undefined bus(es) for for transformer <%s - %s> (data row %d) \n', name_from, name_to, ii) 
        error_code = 1;    
    end
    
    % save From bus  
    if func_ifstr_incell(busset_4branches, name_from)==0 
        busset_4branches{end+1} = name_from;
    end 

    % save To bus  
    if func_ifstr_incell(busset_4branches, name_to)==0
        busset_4branches{end+1} = name_to;
    end         
end



%-------------------------------------------------------------------------------
fprintf('\nChecking for missing buses in branch/transformer data ... \n')  

% Check if all buses are used in branches/transformer data 
for ii=1:N_inbus

    targetbus = busset_inbus{ii};
    
    if func_ifstr_incell(busset_4branches, targetbus)==0
        fprintf('Error: Missing bus <%s> \n', targetbus) 
        error_code = 1;    
    end
end



if error_code >0 
    fprintf(message4return)
    return
end



%-------------------------------------------------------------------------------
% Plotting topology based on IN_pline and IN_trans
fprintf('\nPlotting the grid topology ... \n')  

% create bus matrix with: H, V, U_angle 
HVUang_4plot = zeros(N_inbus,3); 

for ii=1:N_inbus
    onerow_data = IN_bus{ii}; 
    HVUang_4plot(ii,:)= [onerow_data{2}, onerow_data{3}, VmVa_fromuser(ii,2)]; % coordinates H, V, U_angle    
end

% create branch matrix with: From, To, branch type (0-PL, 1-transf), transf. Rn1,Xn1,Rn2,Xn2
branchdata_4plot = [];  

for ii=1:N_inpline
    onerow_data = IN_pline{ii};    
    name_from = onerow_data{1};
    name_to = onerow_data{2}; 

    ind_1 = find(strcmp(busset_inbus, name_from)==1); 
    ind_2 = find(strcmp(busset_inbus, name_to)==1); 
    
    branchdata_4plot = [branchdata_4plot; [ind_1, ind_2, 0, -1, -1, -1, -1]]; % 
end


for ii=1:N_intrans
    
    onerow_data = IN_trans{ii};
    
    name_from = onerow_data{1};
    name_to = onerow_data{2}; 
    
    ind_1 = find(strcmp(busset_inbus, name_from)==1); 
    ind_2 = find(strcmp(busset_inbus, name_to)==1); 
    
    branchdata_4plot = [branchdata_4plot; [ind_1, ind_2, 1, cell2mat(onerow_data(11:14))]];
end


psqm_plot_network(busset_inbus, HVUang_4plot, branchdata_4plot, code_slackbus, code_PUbus, plot_param);



%-------------------------------------------------------------------------------
%-------------------------------------------------------------------------------
% PART II - Conversion to Matpower format 

fprintf('\nConverting data to Matpower format ... \n')  

%
%-------------------------------------------------------------------------------
% Bus and Generator data
% IN_bus: 1-Name, 2-H, 3-V, 4-Ubase, 5-Pd, 6-Qd, 7-Psh, 8-Qsh  

busdat4MP = zeros(N_inbus, 13); 
gendat4MP = zeros(N_slack+N_PUbus, 21); % 10 inputs are defined here, other 11 inputs are zeroed
n_gen = 0;

for ii=1:N_inbus
    
    onerow_data = IN_bus{ii}; 
    
    Ubase_ini = onerow_data{4};
    Ubase = func_closestvalue(standard_Ubase, Ubase_ini, Udev_limit); % replace with the closest standard value 
    
    Pd = onerow_data{5};
    Qd = onerow_data{6};
    
    Gs = onerow_data{7}*(Ubase/Ubase_ini)^2;  % adjustment for the new Ubase
    Bs = onerow_data{8}*(Ubase/Ubase_ini)^2;
        
    angle_input = VmVa_fromuser(ii,2);
    
    if ind_slack==ii  % the only slack bus      
        bustype = 3;  
        ang_sel = 0;  % fixed 
        Pgen = 0; Qgen = 0; % initial gen values
        Pd = 0; Qd = 0;  % ignoring loads  
        Gs = 0; Bs = 0; % ignoring shunts
        
        
    elseif any(ind_PUbus==ii)  % PU bus       
        bustype = 2;  
        ang_sel = 0; % initial value       
        Pgen = -Pd;  Pd = 0; % active load is moved to gen
        Qgen = 0; Qd = 0; % ignoring reactive load  
        Gs = 0; Bs = 0; % ignoring shunts
    
    else   % PQ bus (U, phi initial values may be defined by user)      
        bustype = 1;  ang_sel = angle_input;               
    end
    
    volt_sel = VmVa_fromuser(ii,1)/Ubase;
    if volt_sel==0
        volt_sel = 1; % used mostly for default PQ buses
    end    
    
    if bustype>1
        n_gen = n_gen + 1;
                              % bus	    Pg	  Qg	Qmax  Qmin	 Vg	        mBase	status	Pmax	Pmin
        gendat4MP(n_gen,1:10) = [ii,  Pgen,  Qgen,   300,  -300, volt_sel,	S_base,  1,     300,     0]; 
    end    
    
                     % Bus,  type,    Pd, Qd, Gs, Bs, Area,   Vm,       Va,     Ub(10), Zone, Vmax, Vmin(13)  
    busdat4MP(ii,:) = [ii,   bustype, Pd, Qd, Gs, Bs, 1,    volt_sel,  ang_sel,  Ubase, 1,    1.1,  0.9];      
end


%---------------------------
% Bus data for zero sequence 
% Removed loads/shunts if needed can be modelled via additional transf

busdat4MP_zero = busdat4MP; 

busdat4MP_zero(:,3:4) = 0; % remove all loads

busdat4MP_zero(:,5:6) = 0; % remove all shunts 



%-------------------------------------------------------------------------------
% Branch data (power lines) 
% IN_pline: 1-fbus, 2-tobus, 3-Segmtype_1, 4-Segmlength_1, ... Segmtype_N, Segmlength_N

Nbranch_total = N_inpline + N_intrans;
branchdat4MP = zeros(Nbranch_total, 13); 

branchdat4MP(:,1:2) = branchdata_4plot(:,1:2); % from/tobus indexes
branchdat4MP(:,11) = 1; % all branches are closed! 
branchdat4MP(:,12) = -360;
branchdat4MP(:,13) = 360;

branchdat4MP_zero = branchdat4MP;

for ii=1:N_inpline
    onerow_data = IN_pline{ii};
            
    ind_1 = branchdat4MP(ii,1); % index of frombus
    U1_base = busdat4MP(ind_1,10);
    
    ind_2 = branchdat4MP(ii,2); % index of tobus
    U2_base = busdat4MP(ind_2,10);
    
    Zb_here = U1_base^2/S_base; % ohm, U1_base=U2_base
    
    if U1_base~=U2_base % different (unlikely to occur after the previous checks)
        fprintf('Error: Different Ubase (%d, %d kV) at power line <%s - %s>  \n', ...
        U1_base, U2_base, onerow_data{1}, onerow_data{2})        
        error_code = 1;  
    end
    
    N_segm = segmnumb_inpline(ii);    
    RXB = [0, 0, 0]; 
    RXB_zero = [0, 0, 0]; 
    for ss=1:N_segm        
    
        pos_elem = 2*ss+1; % according to IN_pline format (pltype position 3, 5, 7, etc) 
        pltype = onerow_data{pos_elem};
        L = onerow_data{pos_elem+1}/1000;  % km
        
        ind = find(strcmp(PL_nameextra, pltype)==1); 
                
        % RXB in ohm, Siemens      
        RXB = RXB + L*[PLdata.R(ind), PLdata.X(ind), PLdata.Bd(ind)];  % positive/negative sequence  

        RXB_zero = RXB_zero + L*[PLdata.R0(ind), PLdata.X0(ind), PLdata.Bd0(ind)]; % zero sequence
                
    end

    Smax = 0; %% PL rating not used
    
    % RXB in base units
    multdum = [1/Zb_here, 1/Zb_here, Zb_here];
    RXB = RXB.*multdum;
    RXB_zero = RXB_zero.*multdum;
    
    branchdat4MP(ii, 3:6)= [RXB, Smax]; % save     
    branchdat4MP_zero(ii,3:5) = RXB_zero;
end


%-------------------------------------------------------------------------------
% Branch data (transformers) 
% IN_trans: 1-frombus, 2-tobus, 3-Snom (MVA), 4-U1 (kV), 5-U2 (kV), 6-uk (-), 7-X/R, 8-tap_relpos (+-), 9-tap_step (%), 10-phi (deg)
%           11-Rn1 (ohm), Xn1, Rn2, 14-Xn2


transfdata_out =zeros(N_intrans, 8);  % selected data for output (see below)

for ii=1:N_intrans
    onerow_data = IN_trans{ii};
    
    ii4br = ii+N_inpline; 
    
    ind_1 = branchdat4MP(ii4br,1); % index of frombus
    U1_base = busdat4MP(ind_1,10);
    
    ind_2 = branchdat4MP(ii4br,2); % index of tobus
    U2_base = busdat4MP(ind_2,10);
    
    if U1_base==U2_base % same
        fprintf('Note: Same Ubase (%d, %d kV) at transformer <%s - %s> (data row %d) \n', ...
        U1_base, U2_base, onerow_data{1}, onerow_data{2}, ii)
        % possible for example for regulation transformers
    end
    
    Snom = onerow_data{3}; % MVA
    U1_nom = onerow_data{4}; % kV
    U2_nom = onerow_data{5}; 
    uk = onerow_data{6}; % (-)
    X2R = onerow_data{7}; % (-)
    tap_relpos = onerow_data{8};
    tap_step = onerow_data{9};
    phase_shift = onerow_data{10}; % deg
    input_zeroseq = onerow_data(11:14);
        
    if abs(U1_nom-U1_base)/U1_base>Udev_limit || abs(U2_nom-U2_base)/U2_base>Udev_limit
        fprintf('Error: Unom--Ubase mismatch at transformer <%s - %s> (data row %d): %d--%d kV (frombus), %d--%d kV (tobus) \n', ...
        onerow_data{1}, onerow_data{2}, ii, U1_nom, U1_base, U2_nom, U2_base)  
        error_code = 1;       
    end

    [R, X, tapratio_4calc_nom, tapratio_4calc_OFFnom, Z0t_sh1, Z0t_sh2, Z0t_12]=func_calc_transfparam(...
        Snom, U1_nom, U2_nom, uk, X2R, tap_relpos, tap_step, S_base, U1_base, U2_base, input_zeroseq);
        
    transfdata_out(ii,:) = [ii4br, tapratio_4calc_nom, tapratio_4calc_OFFnom, tap_step, cell2mat(input_zeroseq)];

    
    branchdat4MP(ii4br, 3:6) = [R, X, 0, Snom]; 
    branchdat4MP(ii4br, 9:10) = [tapratio_4calc_OFFnom, phase_shift]; 
    
    % assign zero seq. parameters
    branchdat4MP_zero(ii4br, 3:4)= [real(Z0t_12), imag(Z0t_12)]; % series impedance 
    branchdat4MP_zero(ii4br, 9:10) = [tapratio_4calc_OFFnom, 0]; % same tap, but zero shift 
    
    if Z0t_sh1~=Inf
        dum = 1/Z0t_sh1; 
%        busdat4MP_zero(ind_1, 5:6) = S_base*[real(dum), imag(dum)]; % shunt 1
        busdat4MP_zero(ind_1, 5:6) = busdat4MP_zero(ind_1, 5:6) + S_base*[real(dum), imag(dum)]; % shunt 1, allows shunts from other transf.
    end
    
    if Z0t_sh2~=Inf
        dum = 1/Z0t_sh2;
%        busdat4MP_zero(ind_2, 5:6) = S_base*[real(dum), imag(dum)]; % shunt 2
        busdat4MP_zero(ind_2, 5:6) = busdat4MP_zero(ind_2, 5:6) + S_base*[real(dum), imag(dum)]; % shunt 2, allows shunts from other transf.
    end
end


% branch data for negative sequence (only transformer branches modified)
branchdat4MP_negat = branchdat4MP;

for ii=1:N_intrans
   
    ii4br = ii+N_inpline; 
    branchdat4MP_negat(ii4br,10) = -branchdat4MP(ii4br,10);  % phase shifts are reversed
end



if error_code>0
    fprintf(message4return)
    return
end


% Save to mpc structure 

mpc.version = MP_version;
mpc.baseMVA = S_base;
mpc.bus = busdat4MP;
mpc.gen = gendat4MP;
mpc.branch = branchdat4MP;

mpc.bus_name = busset_inbus;  % extra
mpc.bus_coord = HVUang_4plot(:,1:2); % extra

mpc_zero = mpc;
mpc_zero.bus = busdat4MP_zero;
mpc_zero.branch = branchdat4MP_zero;


mpc_neg = mpc;
mpc_neg.branch = branchdat4MP_negat; 

disp('')
disp('The conversion of input data to Matpower format was successful.')

end % function 
