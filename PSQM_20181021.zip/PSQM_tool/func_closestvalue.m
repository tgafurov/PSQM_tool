

function [out] = func_closestvalue(targetvector, value, dev_limit)

[~, ind] = min(abs(targetvector - value));

value_found = targetvector(ind);

if abs((value_found-value)/value_found)<dev_limit
    out = value_found;
else
    out = 0;
end

end % function