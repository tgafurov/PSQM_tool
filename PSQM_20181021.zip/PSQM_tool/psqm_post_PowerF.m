% PSQM tool, T.Gafurov
% 2018-10-08



function [mpc, error_PF, control_PF] = psqm_post_PowerF(mpc, mpopt, power_unit)

borderline_main = ' >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>';
borderline_sub  =' ------- ';

fprintf('\n\n%s\n', borderline_main)
fprintf(' POWER FLOW ANALYSIS \n') 

control_PF = zeros(1,3); % S_slack, U_lastbus, Ifrom_lastbranch

Nbus = size(mpc.bus,1);
Nbranch = size(mpc.branch,1);

S_base = mpc.baseMVA; 
    
mpc = runpf(mpc, mpopt);

if strcmp(mpopt.pf.alg, 'NR')==1
    Nmax_iter = mpopt.pf.nr.max_it;
else
    Nmax_iter = mpopt.pf.gs.max_it;
end

if mpc.success == 0 || mpc.iterations == Nmax_iter
    error_PF = 1;
    fprintf('\nPower flow calculations are either failed or reached max number of iterations \n')
    return
    
elseif min(mpc.bus(:,8))<0.03 % pu, some small value

    error_PF = 0;
    fprintf('\nCalculated voltages are extremely low in some buses (see below). The results are considered invalid. \n\n')
    disp('      Bus        Umagn')
    disp([mpc.bus(:,1), mpc.bus(:,8)])
    return
   
else    
    error_PF = 0;
end

if power_unit == 0
    mult4power = 1; % MVA                
    str_P = 'MW';
    str_Q = 'MVar';
else
    mult4power = 1000;  % kVA
    str_P = 'kW';
    str_Q = 'kVar';
end


% define dummy bus names if missing
if isfield(mpc, 'bus_name')==0
    for ib = 1:Nbus
        mpc.bus_name{ib} = '---'; 
    end 
end
       
%-------------------------------------------------------------------------------
% Summary data 
% Replace Matpowers native summary ?



%-------------------------------------------------------------------------------
% Bus data
Ubase_all = ones(1,Nbus);
Umagpu_all = ones(1,Nbus);

fprintf('\n\n')
fprintf(' %s BUS data %s \n\n', borderline_sub, borderline_sub)
fprintf('  #     Bus name    U_base    U_magn    U_magn    U_angle     P_load     Q_load      Psh        Qsh \n')
fprintf('                      kV        pu        kV       deg         %2s         %4s       %2s         %4s  \n', ...
str_P, str_Q, str_P, str_Q)

% % U_temp = zeros(Nbus,1); % for testing
% % [Ybus, Yf, Yt] = makeYbus(mpc); % for testing

     
for ib = 1:Nbus

    bus_type = mpc.bus(ib,2);
    
    if bus_type>1  % Swing or PV bus, generation is presented as negative load
        irow = find(mpc.gen(:,1)==ib);
        P_load = -mpc.gen(irow, 2);
        Q_load = -mpc.gen(irow, 3);
        
    else % PQ bus
        P_load = mpc.bus(ib,3);  % MVA, fixed load
        Q_load = mpc.bus(ib,4); 
    end

    Umag=mpc.bus(ib,8);  % pu
    
    phi_U=mpc.bus(ib,9);
    
    Ub_here = mpc.bus(ib,10); % kV, L-L      
    
% %     U_temp(ib) = Umag*(cosd(phi_U) + 1i*sind(phi_U)); % pu, used for testing
    
    P_sh = Umag*mpc.bus(ib,5);  % MVA, shunt power at actual voltage
    Q_sh = Umag*mpc.bus(ib,6); 
    
    busname = mpc.bus_name{ib}; % bus name
    
    % print bus results    
    fprintf('%3d   %10s   %7.2f    %5.3f    %7.3f   %6.1f   %9.2f  %9.2f  %9.2f  %9.2f  \n', ...
        ib, busname, Ub_here,  Umag,  Umag*Ub_here,  phi_U, ...
        P_load*mult4power,  Q_load*mult4power,  P_sh*mult4power,  Q_sh*mult4power)        
    
    % save selected parameters for next step
    Ubase_all(ib) = Ub_here; % kV
    Umagpu_all(ib) = Umag; % pu, magnitude
    
    % save control parameters
    if bus_type==3
        control_PF(1) = P_load + 1i*Q_load; % Power at slack bus
    end
    
    if ib==Nbus
        control_PF(2) = Ub_here*Umag*(cosd(phi_U) + 1i*sind(phi_U)); % Voltage at the last bus
    end
    
end        

% Get total loads and shunts, not needed ?
%Pload_tot = sum(mpc.bus(:,3));  % MVA  
%Qload_tot = sum(mpc.bus(:,4)); 
%
%Psh_tot = sum(mpc.bus(:,8).*mpc.bus(:,5));
%Qsh_tot = sum(mpc.bus(:,8).*mpc.bus(:,6));
%
%fprintf('\n                                                Total   %9.2f  %9.2f  %9.2f  %9.2f  \n', ...
%        Pload_tot*mult4power,  Qload_tot*mult4power,  Psh_tot*mult4power,  Qsh_tot*mult4power)        
        
%Ifr_pu_test = Yf*U_temp; % testing Yf

%-------------------------------------------------------------------------------
% Branch data

for PP = 1:2  % 1 - Trans, 2 - PL
    fprintf('\n\n')
    br_count = 0;
    if PP==1
        fprintf(' %s BRANCH - Transformer data %s \n\n', borderline_sub, borderline_sub) 

        fprintf('  #               Bus name                P_inj (%2s)          Q_inj (%4s)     I_from     dU    Tr_ratio    Tr_shift \n', ...
        str_P, str_Q)
        fprintf('             FROM            TO        FROM         TO       FROM         TO      (A)     (%%)      (-)      (deg) \n')
    else
        fprintf(' %s BRANCH - Power Line data %s \n\n', borderline_sub, borderline_sub) 

        fprintf('  #               Bus name                P_inj (%2s)          Q_inj (%4s)     I_from     dU     I_charge   \n', ...
        str_P, str_Q)
        fprintf('             FROM            TO        FROM         TO       FROM         TO      (A)     (%%)      (A)    \n')
    end    
      
    for jj=1:Nbranch
        
        % read MP parameters
        ib1 = mpc.branch(jj,1);
        ib2 = mpc.branch(jj,2);   
        
        Bc_br = mpc.branch(jj,5);  % total line charging susceptance (p.u.)  

        tap_br = mpc.branch(jj,9); % From/To 
        shift_br = mpc.branch(jj,10); % deg, transformation phase shift
            
        P_from = mpc.branch(jj,14);    
        Q_from = mpc.branch(jj,15);    
        P_to = mpc.branch(jj,16);    
        Q_to = mpc.branch(jj,17);    
        
        % actual transformation ratio  
        trans_ratio = tap_br*Ubase_all(ib1)/Ubase_all(ib2);    
            
        % bus names
        name_From = mpc.bus_name{ib1}; 
        name_To = mpc.bus_name{ib2}; 
        
        I_base = 1000*S_base/Ubase_all(ib1)/sqrt(3);  % A
        
        I_from = 1000*sqrt(P_from^2 + Q_from^2)/(sqrt(3)*Ubase_all(ib1)*Umagpu_all(ib1)); % A
            
        I_charge = 0.5*(Umagpu_all(ib1)+Umagpu_all(ib2))*Bc_br*I_base; % total, A (Ibase is the same for PL endpoints)
            
        % voltage magnitude change due to load 
        U1 = Umagpu_all(ib1);
        U2 = Umagpu_all(ib2);
        
        if tap_br ~= 0 % adjust U1 for the transformation (if any)
            U1 = U1/tap_br;
        end
        
        diff_Umagn = 100*(max(U1,U2) - min(U1,U2))/min(U1,U2);  
        
        % print the branch results
        if PP==1 && tap_br>0   % Transformer
            
            br_count = br_count + 1;
            fprintf('%3d    %10s    %10s   %9.2f  %9.2f  %9.2f  %9.2f   %6.1f   %5.1f   %7.3f     %5.1f \n', ... 
            br_count, name_From, name_To, P_from*mult4power, P_to*mult4power, ...
            Q_from*mult4power, Q_to*mult4power, I_from, diff_Umagn, trans_ratio, shift_br) 
                   
        elseif PP==2 && tap_br==0 % Power line
            br_count = br_count + 1;
            fprintf('%3d    %10s    %10s   %9.2f  %9.2f  %9.2f  %9.2f   %6.1f   %5.1f   %6.1f   \n', ... 
            br_count, name_From, name_To, P_from*mult4power, P_to*mult4power, ...
            Q_from*mult4power, Q_to*mult4power, I_from, diff_Umagn, I_charge)        
        end
        
        % save control parameter 
        if jj==Nbranch
            control_PF(3) = I_from; % Last branch from current
        end  
        
    end
end % PP

end % function 