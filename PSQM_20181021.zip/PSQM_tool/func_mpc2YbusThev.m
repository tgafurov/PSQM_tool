% PSQM tool, T.Gafurov 
% The function transforms mpc struct to Thevenin equivalent by short-circuiting 
% slack and PU buses. And then calculates Ybus, Yf, Yt using Matpowers makeYbus function.

% 2018-10-01

function [Ybus_thev, YF_thev, YT_thev] = func_mpc2YbusThev(mpc)

Nbus = size(mpc.bus,1);

% remove all constant power loads (just in case)
mpc.bus(:,3:4)=0;


% short-curcuit all swing and PV buses 
for ii=1:Nbus
    if mpc.bus(ii,2)>1  % type "2" or "3"
        mpc.bus(ii,5)=1e7; % shunt conductivity in MW        
    end
end

[Ybus_thev, YF_thev, YT_thev] = makeYbus(mpc);

end % function