% PSQM tool, T.Gafurov 
% Calculates the shunt current for a given bus using Matpowers "mpc" struct. 

% If mpc refers to zero-sequence then the currents must be multiplied by 3
% Base voltages in kV, shunt currents in A, phi in degrees

% U_actual - complex, pu (single value!)

% 2018-10-01

function [out] = func_calc_Ish4bus(mpc, bus_ref, U_actual)

U_base = mpc.bus(bus_ref,10); % kV

S_shunt = mpc.bus(bus_ref,5)+1i*mpc.bus(bus_ref,6); % MVA, shunt power at base voltage

phi_U = angle(U_actual)*180/pi();    

I_sh = 1000*U_actual*S_shunt/U_base/sqrt(3);  % A

phi_actual = angle(I_sh)*180/pi();

phi_rel = phi_U - phi_actual;

if abs(phi_rel)>180

    phi_rel = phi_rel - sign(phi_rel)*360;
end

%          1-magn      2-phi_actual   3-Ires_rel               4- Iind_rel               5-phi_rel
out = [abs(I_sh),  phi_actual,    abs(I_sh)*cosd(phi_rel), abs(I_sh)*sind(phi_rel),  phi_rel]; 
   
end % function
   