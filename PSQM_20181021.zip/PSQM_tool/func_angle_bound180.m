

function [out] = func_angle_bound180(phi_deg)
    
    N = max(size(phi_deg));
    out = 0*phi_deg; % same size
    
    for ii=1:N
        A_ini = phi_deg(ii);
        
        if abs(A_ini)>180            
            out(ii) = A_ini - sign(A_ini)*360;
        else
            out(ii) = A_ini;
        end
    end
    
end % function